# -*- coding: utf-8 -*-
"""
Created on Fri Dec 17 18:06:47 2021

@author: chris
"""

from kgc_chart.krueger_class import *
