# -*- coding: utf-8 -*-
"""
Created on Fri Dec 17 18:06:47 2021

@author: chris
"""

from krueger_class import krueger_gauge_circular_chart
